import string

DIGITS = "0123456789"
LETTERS = string.ascii_letters

KEYWORDS = ["func", "if"]